<?php // Silence is golden


// IMPORTANT: ADD THIS TO CUSTOM CSS

// .logged-in-condition .hide-logged-in {
// 	display: none!important;
// }

// .logged-out-condition .hide-logged-out {
// 	display: none!important;
// } 


//ADD THIS TO WOO MY ACCOUNT CUSTOM CSS
// .logged-in-condition selector {
//   display: none;
// }